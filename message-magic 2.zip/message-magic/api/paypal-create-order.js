const { paypalBaseUrl, getAccessToken } = require("./_paypal");

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Methode non autorisee" });
  }

  try {
    const amount = process.env.PRICE_PER_MESSAGE_EUR || "1.52";
    const accessToken = await getAccessToken();

    const orderResponse = await fetch(`${paypalBaseUrl()}/v2/checkout/orders`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        intent: "CAPTURE",
        purchase_units: [
          {
            description: "Message Magic - 1 message genere",
            amount: {
              currency_code: "EUR",
              value: amount,
            },
          },
        ],
      }),
    });

    const orderData = await orderResponse.json();

    if (!orderResponse.ok) {
      return res.status(orderResponse.status).json({ error: orderData });
    }

    res.status(200).json({ orderId: orderData.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
