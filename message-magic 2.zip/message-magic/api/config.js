// Renvoie uniquement des infos publiques au frontend.
// Le PAYPAL_CLIENT_SECRET et l'OPENAI_API_KEY ne sont JAMAIS envoyes ici.
module.exports = (req, res) => {
  res.status(200).json({
    paypalClientId: process.env.PAYPAL_CLIENT_ID || "",
    pricePerMessageEur: process.env.PRICE_PER_MESSAGE_EUR || "1.52",
  });
};
