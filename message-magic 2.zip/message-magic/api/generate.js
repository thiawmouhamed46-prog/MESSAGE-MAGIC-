const { paypalBaseUrl, getAccessToken } = require("./_paypal");

async function verifyOrderPaid(orderId) {
  const accessToken = await getAccessToken();
  const response = await fetch(`${paypalBaseUrl()}/v2/checkout/orders/${orderId}`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!response.ok) return false;
  const data = await response.json();
  return data.status === "COMPLETED";
}

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Methode non autorisee" });
  }

  const { orderId, theme, details, ton, destinataire } = req.body || {};

  if (!orderId) {
    return res.status(400).json({ error: "Paiement manquant. orderId requis." });
  }
  if (!theme || !theme.trim()) {
    return res.status(400).json({ error: "Le theme du message est requis." });
  }

  try {
    // Etape critique de securite : on ne genere JAMAIS un message sans
    // avoir verifie aupres de PayPal que ce orderId a bien ete paye.
    const isPaid = await verifyOrderPaid(orderId);
    if (!isPaid) {
      return res.status(402).json({ error: "Paiement non confirme pour cette commande." });
    }

    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: "Cle OpenAI manquante cote serveur." });
    }

    const systemPrompt =
      "Tu es Message Magic, le meilleur redacteur de messages personnalises au monde. " +
      "Tu ecris des messages plus percutants, plus originaux et plus adaptes que n'importe " +
      "quel autre generateur. Reponds uniquement avec le message final, sans explications, " +
      "sans guillemets, sans introduction.";

    const userPrompt = [
      `Theme: ${theme}`,
      ton ? `Ton souhaite: ${ton}` : null,
      destinataire ? `Destinataire: ${destinataire}` : null,
      details ? `Details a inclure: ${details}` : null,
      "Ecris un message pret a etre envoye tel quel.",
    ]
      .filter(Boolean)
      .join("\n");

    const completion = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.9,
      }),
    });

    const completionData = await completion.json();

    if (!completion.ok) {
      return res.status(completion.status).json({ error: completionData });
    }

    const message = completionData.choices?.[0]?.message?.content?.trim() || "";
    res.status(200).json({ message });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
