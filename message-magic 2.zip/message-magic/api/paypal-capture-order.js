const { paypalBaseUrl, getAccessToken } = require("./_paypal");

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Methode non autorisee" });
  }

  const { orderId } = req.body || {};
  if (!orderId) {
    return res.status(400).json({ error: "orderId manquant" });
  }

  try {
    const accessToken = await getAccessToken();

    const captureResponse = await fetch(
      `${paypalBaseUrl()}/v2/checkout/orders/${orderId}/capture`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
      }
    );

    const captureData = await captureResponse.json();

    if (!captureResponse.ok) {
      return res.status(captureResponse.status).json({ error: captureData });
    }

    const status = captureData.status;
    res.status(200).json({ status, orderId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
