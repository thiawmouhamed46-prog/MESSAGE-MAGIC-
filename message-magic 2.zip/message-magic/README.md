# Message Magic

Générateur de messages personnalisés par IA, avec paiement PayPal à l'unité (1000 FCFA / message).

## ⚠️ À faire avant tout

Tu as partagé ton Client ID **et** ton Client Secret PayPal dans une conversation.
Le Secret doit être considéré comme compromis :

1. Va sur https://developer.paypal.com/dashboard/
2. Régénère un nouveau Client Secret pour ton app.
3. Utilise uniquement les **nouvelles** clés ci-dessous. Ne les mets jamais dans un fichier
   que tu commits sur GitHub ou que tu envoies par message.

## Pourquoi ce n'est pas "un seul fichier HTML"

Deux choses ont besoin d'un vrai serveur pour fonctionner sans être piratables :

- **Vérifier le paiement PayPal** avant de délivrer le message (sinon n'importe qui peut
  ouvrir la console du navigateur et débloquer le message gratuitement).
- **Appeler l'API OpenAI** pour générer le texte (la clé API ne peut pas être visible dans
  le code envoyé au navigateur).

C'est pour ça que le projet contient un dossier `api/` : ce sont des petites fonctions
serveur (elles tournent automatiquement sur Vercel, gratuitement). Tu n'as rien à coder,
juste à déposer le dossier.

## Déploiement sur Vercel (gratuit, ~5 minutes)

1. Crée un compte sur https://vercel.com (tu peux te connecter avec GitHub, Google ou email).
2. Sur le dashboard Vercel, clique **Add New → Project**.
3. Choisis **"Deploy without Git"** / glisse-dépose directement le dossier `message-magic`
   (ou pousse-le sur un repo GitHub puis importe-le, si tu veux des mises à jour faciles plus tard).
4. Avant de cliquer sur Deploy, ouvre **Environment Variables** et ajoute :

   | Nom | Valeur |
   |---|---|
   | `PAYPAL_CLIENT_ID` | ton nouveau Client ID PayPal |
   | `PAYPAL_CLIENT_SECRET` | ton nouveau Client Secret PayPal |
   | `PAYPAL_ENV` | `sandbox` pour tester, `live` pour du vrai argent |
   | `OPENAI_API_KEY` | ta clé OpenAI (platform.openai.com/api-keys) |
   | `PRICE_PER_MESSAGE_EUR` | `1.52` (équivalent exact de 1000 FCFA) |

5. Clique **Deploy**. Vercel te donne une URL du type `message-magic.vercel.app`.
6. Teste d'abord en mode `PAYPAL_ENV=sandbox` avec un compte PayPal sandbox
   (créé automatiquement dans developer.paypal.com/dashboard/accounts).
7. Quand tout fonctionne, repasse `PAYPAL_ENV` sur `live` et redéploie.

## Obtenir une clé OpenAI

1. Crée un compte sur https://platform.openai.com
2. Ajoute un petit crédit (quelques dollars suffisent pour des centaines de messages avec gpt-4o-mini).
3. Génère une clé dans **API Keys** et colle-la dans `OPENAI_API_KEY` sur Vercel.

## Important : PayPal et le FCFA

PayPal ne supporte pas le franc CFA (XOF) comme devise. Le site facture donc
l'équivalent en euros. Comme le XOF est indexé sur l'euro à taux fixe
(1 € = 655,957 FCFA), la conversion de 1000 FCFA donne exactement **1,52 €** —
ce n'est pas une estimation, ce taux ne bouge jamais. Si tu veux rester 100% en
FCFA sans passer par une devise étrangère, il faudra remplacer PayPal par
**Wave** ou **Orange Money**, qui ont leurs propres API — dis-le-moi et je peux
adapter le projet dans une prochaine version.

## Ce qui est fonctionnel dès maintenant

- ✅ Génération de message par IA, thème/ton/destinataire/détails personnalisables
- ✅ Paiement PayPal à l'unité (1000 FCFA / message) avec vérification serveur
  (impossible de générer un message sans paiement confirmé)
- ✅ Dashboard avec ton logo, boutons ronds, sections Accueil / Paiement / Historique

## Ce qui reste à construire (phase 2)

- ⏳ Abonnement mensuel récurrent (nécessite PayPal Subscriptions API + une base de
  données pour suivre qui est abonné — je peux le faire dans un prochain échange)
- ⏳ Historique persistant (actuellement, l'historique disparaît si on recharge la page ;
  pour le garder il faut une base de données comme Vercel Postgres ou Supabase)

## Structure du projet

```
message-magic/
  api/
    config.js                 -> infos publiques (client id PayPal, prix)
    _paypal.js                -> utilitaires PayPal (privé)
    paypal-create-order.js    -> crée une commande PayPal
    paypal-capture-order.js   -> capture le paiement
    generate.js                -> vérifie le paiement puis génère le message via OpenAI
  public/
    index.html                 -> le dashboard (frontend)
    logo.png                   -> ton icône
  .env.example                 -> modèle des variables d'environnement
  vercel.json
  package.json
```
